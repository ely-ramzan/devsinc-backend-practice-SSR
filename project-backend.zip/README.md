# todo: eslint prettier - todos ::::> search: pagination sorting filtering chartjs
# react zustand tanstack-react-query axios shadcn